from django.contrib import admin
from .models import Course,Category, Slider
# Register your models here.

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ("title","isActive","isHome","slug","category_list",) #burda admin panelinde gözüken özelliklerimizden title ve isActive'in yanında slug bilgisini de görmek istedik
    list_display_links = ("title","slug",) #üzerine tıklandığında detay sayfasına gidecek linkleri belirliyoruz.
    prepopulated_fields ={"slug":("title",),} #title a göre slug bilgisini atıyoruz
    # readonly_fields = ("slug",)#sadece okunabilir alanları belirliyoruz
    list_filter = ("title","isActive","isHome")#hangi alanlara göre filtreleme işlemleri yapabileceğimizi belirliyoruz.
    list_editable = ("isActive","isHome",)#admin panelinden direkt değişiklik yapabileceğimiz özellikleri belirliyoruz.
    search_fields = ("title","description")#arama işleminin neye göre yapacağımızı belirliyoruz.
    #bu arada admin sayfasında tek özellik için değişiklik yapacaksan tek özellikten sonra virgül ekle
    
    def category_list(self, obj):
        html = ""
        for category in obj.categories.all():
            html += category.name + " "
        return html


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name","slug","course_count")
    prepopulated_fields ={"slug":("name",),}

    def course_count(self, obj):
        return obj.course_set.count()
    
admin.site.register(Slider)