from django.db import models
from django.utils.text import slugify
from ckeditor.fields import RichTextField

# Create your models here.

class Category(models.Model):
    name = models.CharField(max_length=40)
    slug = models.SlugField(default="", null=False,unique=True,db_index=True,max_length=50)
    def __str__(self):
        return f"{self.name}"

class Course(models.Model):
    title = models.CharField(max_length=30, null=True)#charfield karakter için ve (max_length=30, null=True) bunu dediğimizde en fazla 30 karakter girebilir ve bu alanı boş bırakabilir.
    subtitle = models.CharField(max_length=100, default="")
    description = RichTextField()#bu ckeditor gibi bir yeri kullandığımız yer
    image = models.ImageField(upload_to="images", default="")#ayrıca bull veri tabanı tablosu oluştururken önemlidir. blank ise kullanıcı tarafı için önemli dir kullanıcıya boş bırakıp bırakılmayacağı belirtilir. "blank = True" demek bu alanın boş olmasına izin verilir demektir.
    date = models.DateField(auto_now=True)
    isActive = models.BooleanField(default=False)
    isHome = models.BooleanField(default=False)
    slug = models.SlugField(default="",blank=True, null=False, unique=True, db_index=True)#editable=False, -> eski durum için slug bilgisini editleme imkanını kaldırmıştık şu anki kodla alakası yok ama kullanılabilir
    #Category = models.ForeignKey(Category,default=1, on_delete=models.CASCADE, related_name="kurslar") burada cascade yerine set_null gibi ifadelerde diyebilirdik ama o zaman null=true veyahut diyeceğimiz ifadeye göre mesela default=1 gibi bir değer atamalıyız ki o category'i sildiğimizde sorun yaşamayalım bu cascade ile category silince ilgili Course'ların hepsini siliyor.
    categories = models.ManyToManyField(Category)#bunu Category classında da yapabilirdin Course diyerek nerede yapacağın çok önemli değil.

    # def save(self, *args, **kwargs):
    #     self.slug = slugify(self.title)
    #     super().save(args,kwargs)
    #     shell'in üzerinden In [2]: Course.objects.get(pk=1).save() dediğimizde slug olarak veritabanına kaydeder.
    def __str__(self):
        return f"{self.title}" #bu metodlada shell'e geçtiğimizde(veri tabanı için geçitiğimiz python shelli) Course.objects.all() şunu dediğimizde bizim istediğimiz sorgu cevaplarını gösteriyor.

    #modeli oluşturduktan sonra migration oluşturmak gererkir.
    #python manage.py migrate ile daha önce hiç migrate etmemiştik ilk kez migrate ediyoruz ve daha önce aslında uygulama oluşturulurkende oluşan uygulamalar migrate ediliyor.
    #python manage.py makemigration ile de kendi migrationlarımızı oluşturuyoruz. Bunu normal olan migrationslardan farklı olarak biz oluşturduğumuz içinde ek .py dosyası oluşturuyor.   
    #daha sonra da oluşturduğun migrationsları veri tabanına migrate etmeyi unutma!
#    >>> from blog.models import Blog
#    >>> b = Blog(name="Beatles Blog", tagline="All the latest Beatles news.")
#    >>> b.save() -> bu üç kod parçası verilerimizi veri tabanına sql sorgusu göndermesini sağlar
# ayrıca uygulamaya sorgu yazmamız için "pyhton manage.py shell" dememiz lazım
# aşağıda yukarıdaki shell i yazdıktan sonra terminalden database için bir obje oluşturmamız ve ona eleman tanımlamamızı anlatan kod satırları yer alıyor.
#In [1]: from courses.models import Course

# In [2]: from datetime import datetime

# In [3]: kurs1 = Course(title="javascript kursu", description="güzel kurs", imageUrl="js.jpeg", date=datetime.now(), isActive=1)

# In [4]: kurs1
# Out[4]: <Course: Course object (None)>

# In [5]: kurs1.title
# Out[5]: 'javascript kursu'
#kurs1.save() -> veri tabanına kayıt edilme işlemini tamamlıyor.
#In [11]: Course.objects.create(title="php kursu", description="güzel kurs", imageUrl="webgelistirme.jpeg", date=datetime.now(), isActive=1) -> bu yöntem ile save'i tekrar çağırmadan veri tabanına direkt kayıt etmiş oluyoruz.


#************************
# In [12]: Course
# Out[12]: courses.models.Course
# In [13]: Course.objects
# Out[13]: <django.db.models.manager.Manager at 0x1f487df2d50>
# In [14]: Course.objects.all()
# Out[14]: <QuerySet [<Course: Course object (1)>, <Course: Course object (2)>, <Course: Course object (3)>, <Course: Course object (4)>]>
# In [15]: kurslar = Course.objects.all()
# In [16]: kurslar
# Out[16]: <QuerySet [<Course: Course object (1)>, <Course: Course object (2)>, <Course: Course object (3)>, <Course: Course object (4)>]>
# In [17]: kurslar[0]
# Out[17]: <Course: Course object (1)>
#In [18]: kurslar[1].title
#Out[18]: 'python kursu'
# In [19]: a = Course.objects.get(pk=1)
# In [20]: a.title
# Out[20]: 'javascript kursu'
# Burada Course objesinin var olup olmadğına bakma Course objesini başka bir değişkene atama ve o değişken üzerinden bildirimler gibi etkinlikler yaptık.

#********************
#Filtreleme sorgusu için de -> In [2]: Course.objects.filter(isActive=1)
#Out[2]: <QuerySet [<Course: javascript kursu 2024-07-09>, <Course: python kursu 2024-07-09>, <Course: asp.net kursu 2024-07-09>, <Course: php kursu 2024-07-09>]>
#diyoruz ve seçtiğimiz koşullar gelmiş oluyor.

# In [5]: Course.objects.filter(date__lte='2025-01-01')
# Out[5]: <QuerySet [<Course: javascript kursu 2024-07-09>, <Course: python kursu 2024-07-09>, <Course: asp.net kursu 2024-07-09>, <Course: php kursu 2024-07-09>]>
# Dediğimizde de yazdığımız tarihten önceki verileri getirioyr lte dediğimiz için küçük veriler gte deseydik yadığımızdan büyük veriler olurdu gt ya da lt deseydikte yazdığımızdan küçük veyahut sadece büyük veriler gelirdi eşit veriler gelmezdi.


#kurs ekleme için aşağıdaki command prompt komutlarını yaptık ama öncesinde mdoelsdeki date tarihini güncelledik ve migrations yaptık
# In [1]: from courses.models import Course,Category

# In [2]: c1 = Category.objects.get(pk=1)

# In [3]: c1
# Out[3]: <Category: Programlama>

# In [4]: kurs = Course(title="angular kursu", description="iyi kurs", imageUrl="webgelistirme.jpeg",isActive=True, Category=c1)

# In [5]: kurs
# Out[5]: <Course: angular kursu>

# In [6]: kurs.save()




#Burada da başka tablonun özelliklerine ulaşma amacıyla kullanılan yöntemleri belirtiyor
# In [1]: from courses.models import Course,Category

# In [2]: kurslar = Course.objects.filter(isActive=True)

# In [3]: kurslar = Course.objects.filter(Category__name="programlama")

# In [4]: kurslar
# Out[4]: <QuerySet []>

# In [5]: kurslar = Course.objects.filter(Category__name="Programlama")

# In [6]: kurslar
# Out[6]: <QuerySet [<Course: Javascript Dersleri>, <Course: Web Geliştirme Kursu>, <Course: angular kursu>]>

# In [7]: kurslar = Course.objects.filter(Category__id="4")

# In [8]: kurslar
# Out[8]: <QuerySet []>

# In [9]: kurslar = Course.objects.filter(Category__id="5")

# In [10]: kurslar
# Out[10]: <QuerySet [<Course: Python Dersleri>]>

# In [11]: kurslar = Course.objects.filter(Category__name__contains="Program")

# In [12]: kurslar
# Out[12]: <QuerySet [<Course: Javascript Dersleri>, <Course: Web Geliştirme Kursu>, <Course: angular kursu>]>

# In [1]: from courses.models import Course,Category

# In [2]: c1 = Category.objects.get(pk=1)

# In [3]: c1.kurslar.all()
# Out[3]: <QuerySet [<Course: Javascript Dersleri>, <Course: Web Geliştirme Kursu>, <Course: angular kursu>]> --> related_name="kurslar" yukarıda bunu ekledikten sonra böyle bir araştırma yapılabilir.

class Slider(models.Model):
    title = models.CharField(max_length=100)
    image = models.ImageField(upload_to="images")
    is_active = models.BooleanField(default=False)
    course = models.ForeignKey(Course, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return f"{self.title}"


class UploadModel(models.Model):
    image = models.ImageField(upload_to="images")